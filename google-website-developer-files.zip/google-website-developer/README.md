# Google Website Developer — static website starter

Responsive website starter with home, services, about, portfolio, privacy, terms and four practical guides.

## Before publishing
- The enquiry form is front-end only. It does not email or store submissions until a backend or form service is connected.
- Privacy and Terms are starter drafts; complete business/contact details and review them before launch.
- Replace `YOUR-DOMAIN-HERE` in `sitemap.xml` after choosing a domain.
- Portfolio is labelled as illustrative concepts, not real client work.
- This static package does not include Hatchable's private API or owner-only lead inbox.

## Upload to GitHub
Extract this ZIP on your phone/computer. In the repository choose **Add file → Upload files**, upload the extracted files and folders (not the ZIP file itself), then commit changes.

## Free static hosting
After uploading, connect the GitHub repository to Cloudflare Pages. Use the repository root as the output directory and leave build command blank for this plain static site.
